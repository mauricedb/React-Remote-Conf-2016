# TheMovieDatabase.Posters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thumbnail** | **String** |  | [optional] 
**profile** | **String** |  | [optional] 
**detailed** | **String** |  | [optional] 
**original** | **String** |  | [optional] 


