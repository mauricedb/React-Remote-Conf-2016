# TheMovieDatabase.MovieRatings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**criticsScore** | **Integer** |  | [optional] 
**audienceScore** | **Integer** |  | [optional] 


