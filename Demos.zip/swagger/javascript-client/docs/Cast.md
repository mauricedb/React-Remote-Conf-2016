# TheMovieDatabase.Cast

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**name** | **String** |  | 
**characters** | **[String]** |  | [optional] 


